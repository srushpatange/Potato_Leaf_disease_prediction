# AICTE-Internship-Potato-project

Describe about the project.

## How to execute the project?
